<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Szavazás Kezdőlap</title>
  <link rel="stylesheet" href="css/style.css">
  <script src="userbox.js"></script>
</head>
<body>

  <div id="userbox"></div>
  <nav id="mainnav"></nav>

  <h1>Elérhető kérdések</h1>

  <ul id="question-list">
    <li>Betöltés...</li>
  </ul>

  <script>
    async function loadQuestions() {
      const list = document.getElementById('question-list');
      try {
        // A 'vote/api/...' helyett simán 'api/...' kell, ha a fájl a gyökérben van
        const res = await fetch('api/dashboard.php');
        
        if (!res.ok) {
          throw new Error(`Szerver hiba: ${res.status} ${res.statusText}`);
        }

        const questions = await res.json();
        list.innerHTML = '';

        if (!questions || questions.length === 0) {
          list.innerHTML = '<li>Jelenleg nincsenek elérhető kérdések az adatbázisban.</li>';
          return;
        }

        questions.forEach(q => {
          const li = document.createElement('li');
          li.innerHTML = `
            <div style="margin-bottom: 10px;">
              <strong style="font-size: 1.2em; color: #af0;">${q.qtext}</strong>
            </div>
            <a href="poll.html?qid=${q.qid}">[Szavazok]</a>
            <a href="result.html?qid=${q.qid}" style="margin-left: 20px;">[Eredmények]</a>
          `;
          list.appendChild(li);
        });
      } catch (err) {
        list.innerHTML = `<li style="color: #f0f;">Hiba: ${err.message}</li>`;
        console.error("Részletes hiba:", err);
      }
    }

    loadQuestions();
  </script>
</body>
</html>
