<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);
ini_set('html_errors', 0);
error_reporting(E_ALL);

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode(["error" => "PHP hiba: $errstr ($errfile:$errline)"]);
    exit;
});

require __DIR__ . '/./require_admin.php'; 
require __DIR__ . '/../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$qtext = trim($data['qtext'] ?? '');
$answers = $data['answers'] ?? [];

if ($qtext === '' || !is_array($answers) || count($answers) < 2) {
    http_response_code(400);
    echo json_encode(["error" => "Legalább egy kérdés és két válasz szükséges."]);
    exit;
}

$conn->begin_transaction();

try {
    $stmt = $conn->prepare("INSERT INTO question (qtext) VALUES (?)");
    $stmt->bind_param("s", $qtext);
    $stmt->execute();
    $qid = $stmt->insert_id;
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO answer (qid, atext) VALUES (?, ?)");
    foreach ($answers as $atext) {
        $atext = trim($atext);
        if ($atext !== '') {
            $stmt->bind_param("is", $qid, $atext);
            $stmt->execute();
        }
    }
    $stmt->close();

    $conn->commit();
    echo json_encode(["message" => "Kérdés és válaszok sikeresen mentve.", "qid" => $qid]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["error" => "Mentési hiba: " . $e->getMessage()]);
}
