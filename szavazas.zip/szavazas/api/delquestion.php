<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/../db.php';

$input = json_decode(file_get_contents('php://input'), true);
$qid = intval($input['qid'] ?? 0);

if ($qid <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Hiányzó vagy érvénytelen kérdésazonosító."]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM question WHERE qid = ?");
$stmt->bind_param("i", $qid);

if ($stmt->execute()) {
    echo json_encode(["message" => "Kérdés törölve."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Hiba a törlés során: " . $conn->error]);
}
$stmt->close();
