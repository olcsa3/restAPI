<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// Admin (uid=0) kivétel
if (
    (!array_key_exists('uid', $_SESSION) || !array_key_exists('name', $_SESSION))
    && (($_SESSION['role'] ?? '') !== 'admin')
) {
    http_response_code(401);
    echo json_encode(["error" => "Bejelentkezés szükséges."]);
    exit;
}

