<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');
error_reporting(E_ALL);

require __DIR__ . '/require_login.php';
require __DIR__ . '/../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$qid = intval($data['qid'] ?? 0);
$qtext = trim($data['qtext'] ?? '');

if ($qid <= 0 || $qtext === '') {
    http_response_code(400);
    echo json_encode(["error" => "Hiányzó adatok a módosításhoz."]);
    exit;
}

$stmt = $conn->prepare("UPDATE question SET qtext = ? WHERE qid = ?");
$stmt->bind_param("si", $qtext, $qid);

if ($stmt->execute()) {
    if ($conn->affected_rows > 0) {
        echo json_encode(["message" => "Kérdés sikeresen módosítva."]);
    } else {
        echo json_encode(["message" => "Nem történt változás vagy a kérdés nem található."]);
    }
} else {
    http_response_code(500);
    echo json_encode(["error" => "Adatbázis hiba: " . $conn->error]);
}
$stmt->close();
