<?php
require 'db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['id']) || !is_numeric($data['id'])) {
        http_response_code(400);
        echo json_encode(["error" => "Hiányzó vagy hibás felhasználóazonosító"]);
        exit;
    }

    $uid = (int)$data['id'];
    $newName = isset($data['name']) ? trim($data['name']) : null;
    $newPass = isset($data['pass']) ? trim($data['pass']) : null;

    if ($newName === null && $newPass === null) {
        http_response_code(400);
        echo json_encode(["error" => "Név vagy jelszó megadása szükséges"]);
        exit;
    }

    // Felhasználó létezik?
    $stmt = $conn->prepare("SELECT name FROM user WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        http_response_code(404);
        echo json_encode(["error" => "A felhasználó nem található"]);
        exit;
    }

    // Ha név módosul, ellenőrizzük, hogy nem foglalt-e
    if ($newName && $newName !== $user['name']) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM user WHERE name = ?");
        $stmt->bind_param("s", $newName);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
        if ($count > 0) {
            http_response_code(409);
            echo json_encode(["error" => "Ez a név már foglalt"]);
            exit;
        }
    }

    // Módosítás összeállítása
    $fields = [];
    $types = "";
    $params = [];

    if ($newName) {
        $fields[] = "name = ?";
        $types .= "s";
        $params[] = $newName;
    }

    if ($newPass) {
        $fields[] = "pass = ?";
        $types .= "s";
        $params[] = password_hash($newPass, PASSWORD_DEFAULT);
    }

    if (!empty($fields)) {
        $sql = "UPDATE user SET " . implode(", ", $fields) . " WHERE uid = ?";
        $types .= "i";
        $params[] = $uid;

        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
    }

    echo json_encode(["message" => "Felhasználó módosítva", "id" => $uid]);
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Nem támogatott metódus"]);
