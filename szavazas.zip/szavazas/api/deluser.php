<?php
require 'require_admin.php'; // Csak admin törölhet
require 'db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        http_response_code(400);
        echo json_encode(["error" => "Hiányzó vagy hibás felhasználóazonosító"]);
        exit;
    }

    $uid = (int)$_GET['id'];

    // Létezik-e a felhasználó?
    $stmt = $conn->prepare("SELECT uid FROM user WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows === 0) {
        http_response_code(404);
        echo json_encode(["error" => "A felhasználó nem található"]);
        exit;
    }
    $stmt->close();

    // Felhasználó törlése
    $stmt = $conn->prepare("DELETE FROM user WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();

    http_response_code(200);
    echo json_encode(["message" => "Felhasználó törölve", "uid" => $uid]);
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Nem támogatott metódus"]);
