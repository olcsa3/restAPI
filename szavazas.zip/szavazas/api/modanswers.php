<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', '0');
ini_set('html_errors', '0');
error_reporting(E_ALL);

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode(["error" => "PHP hiba: $errstr ($errfile:$errline)"]);
    exit;
});

require __DIR__ . '/require_admin.php';
require __DIR__ . '/../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$qid = intval($data['qid'] ?? 0);
$answers = $data['answers'] ?? [];

if ($qid <= 0 || !is_array($answers) || count($answers) < 2) {
    http_response_code(400);
    echo json_encode(["error" => "Érvénytelen kérdésazonosító vagy túl kevés válasz."]);
    exit;
}

// Ellenőrzés: van-e már szavazat?
$stmt = $conn->prepare("SELECT COUNT(*) FROM vote WHERE qid = ?");
$stmt->bind_param("i", $qid);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();

if ($count > 0) {
    http_response_code(403);
    echo json_encode(["error" => "A kérdés már kapott szavazatot, a válaszok nem módosíthatók."]);
    exit;
}

$conn->begin_transaction();

try {
    // Régi válaszok törlése
    $stmt = $conn->prepare("DELETE FROM answer WHERE qid = ?");
    $stmt->bind_param("i", $qid);
    $stmt->execute();
    $stmt->close();

    // Új válaszok beszúrása
    $stmt = $conn->prepare("INSERT INTO answer (qid, atext) VALUES (?, ?)");
    foreach ($answers as $atext) {
        $atext = trim($atext);
        if ($atext !== '') {
            $stmt->bind_param("is", $qid, $atext);
            $stmt->execute();
        }
    }
    $stmt->close();

    $conn->commit();
    echo json_encode(["message" => "Válaszok sikeresen frissítve."]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(["error" => "Hiba a módosítás során: " . $e->getMessage()]);
}
