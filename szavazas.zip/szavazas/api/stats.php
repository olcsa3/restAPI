<?php
require 'require_admin.php'; // Csak admin láthatja az összesítést
require 'db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Összes kérdés
    $res = $conn->query("SELECT COUNT(*) FROM question");
    $totalQuestions = (int)$res->fetch_row()[0];

    // Összes válasz
    $res = $conn->query("SELECT COUNT(*) FROM answer");
    $totalAnswers = (int)$res->fetch_row()[0];

    // Összes szavazat
    $res = $conn->query("SELECT COUNT(*) FROM vote");
    $totalVotes = (int)$res->fetch_row()[0];

    // Összes felhasználó
    $res = $conn->query("SELECT COUNT(*) FROM user");
    $totalUsers = (int)$res->fetch_row()[0];

    // Aktív szavazók száma
    $res = $conn->query("SELECT COUNT(DISTINCT uid) FROM vote");
    $activeVoters = (int)$res->fetch_row()[0];

    echo json_encode([
        "questions" => $totalQuestions,
        "answers" => $totalAnswers,
        "votes" => $totalVotes,
        "users" => $totalUsers,
        "active_voters" => $activeVoters
    ]);
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Nem támogatott metódus"]);
