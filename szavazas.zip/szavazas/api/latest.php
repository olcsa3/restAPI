<?php
require __DIR__ . '/../db.php';
header('Content-Type: application/json; charset=utf-8');

$res = $conn->query("SELECT qid FROM question ORDER BY qid DESC LIMIT 1");
if ($res && $row = $res->fetch_assoc()) {
    echo json_encode(['qid' => $row['qid']]);
} else {
    echo json_encode(['qid' => null]);
}
