<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);
error_reporting(E_ALL);

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode(["error" => "PHP hiba: $errstr ($errfile:$errline)"]);
    exit;
});

// KIVÉVE: require_admin.php - mert a kezdőlapnak látnia kell a kérdéseket bejelentkezés nélkül is!
require __DIR__ . '/../db.php';

// Kérdések lekérdezése
$qstmt = $conn->prepare("SELECT qid, qtext FROM question ORDER BY qid DESC");
if (!$qstmt) {
    http_response_code(500);
    echo json_encode(["error" => "Lekérdezési hiba: " . $conn->error]);
    exit;
}
$qstmt->execute();
$qresult = $qstmt->get_result();

$questions = [];

while ($q = $qresult->fetch_assoc()) {
    $qid = (int)$q['qid'];

    // Válaszok lekérdezése az adott kérdéshez
    $astmt = $conn->prepare("SELECT aid, atext FROM answer WHERE qid = ?");
    $astmt->bind_param("i", $qid);
    $astmt->execute();
    $aresult = $astmt->get_result();
    
    $answers = [];
    while ($a = $aresult->fetch_assoc()) {
        $answers[] = [
            "aid" => (int)$a['aid'],
            "atext" => $a['atext']
        ];
    }
    $astmt->close();

    $q['answers'] = $answers;
    $questions[] = $q;
}
$qstmt->close();

echo json_encode($questions);
