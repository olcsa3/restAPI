<?php
require 'db.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // MySQLi lekérdezés: uid és name párosok
    $result = $conn->query("SELECT uid, name FROM user ORDER BY name ASC");
    if ($result) {
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    } else {
        echo json_encode([]);
    }
    exit;
}

http_response_code(405);
echo json_encode(["error" => "Nem támogatott metódus"]);
