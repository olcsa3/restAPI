<?php
session_start();
require __DIR__ . '/../db.php';
header('Content-Type: application/json');

// Ellenőrizzük, hogy be van-e jelentkezve BÁRKI (user vagy admin)
if (!isset($_SESSION['uid'])) {
    http_response_code(401);
    echo json_encode(["error" => "A szavazáshoz be kell jelentkezned!"]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$qid = intval($data['qid'] ?? 0);
$aid = intval($data['aid'] ?? 0);
$uid = $_SESSION['uid'];
$ip = $_SERVER['REMOTE_ADDR'];

if ($qid <= 0 || $aid <= 0) {
    echo json_encode(["error" => "Érvénytelen kérdés vagy válasz azonosító."]);
    exit;
}

// Ellenőrizzük, hogy szavazott-e már erre a kérdésre (UID alapján)
$check = $conn->prepare("SELECT vid FROM vote WHERE uid = ? AND qid = ?");
$check->bind_param("ii", $uid, $qid);
$check->execute();
if ($check->get_result()->num_rows > 0) {
    echo json_encode(["error" => "Te már szavaztál erre a kérdésre!"]);
    exit;
}

// Szavazat mentése IP címmel együtt a nagyobb biztonság érdekében
$stmt = $conn->prepare("INSERT INTO vote (uid, qid, aid, ip) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiis", $uid, $qid, $aid, $ip);

if ($stmt->execute()) {
    echo json_encode(["message" => "Köszönjük a szavazatodat!"]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Adatbázis hiba: " . $conn->error]);
}

$stmt->close();
$conn->close();
