<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Szavazás Kezdőlap</title>
  <link rel="stylesheet" href="/vote/css/style.css">
  <script src="userbox.js"></script>
</head>
<body>

  <div id="userbox"></div>
  <nav id="mainnav"></nav>

  <h1>Elérhető kérdések</h1>

  <ul id="question-list"></ul>

  <script>
    // Ez a "Híd": a JS elkéri az adatot az API-tól
    async function loadQuestions() {
      try {
        const res = await fetch('/vote/api/dashboard.php');
        const questions = await res.json();
        
        const list = document.getElementById('question-list');
        list.innerHTML = ''; // Ürítés

        questions.forEach(q => {
          const li = document.createElement('li');
          li.innerHTML = `
            <strong style="color: #af0;">${q.qtext}</strong><br>
            <a href="poll.html?qid=${q.qid}">[Szavazok]</a>
            <a href="result.html?qid=${q.qid}" style="margin-left: 10px;">[Eredmények]</a>
          `;
          list.appendChild(li);
        });
      } catch (err) {
        console.error("Nem sikerült betölteni a kérdéseket.");
      }
    }

    loadQuestions();
  </script>
</body>
</html>
