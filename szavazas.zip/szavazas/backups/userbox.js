document.addEventListener("DOMContentLoaded", () => {
  const userbox = document.getElementById('userbox');
  const mainNav = document.getElementById('mainnav');

  Promise.all([
    fetch('api/me.php', { credentials: 'include' }).then(res => res.json()),
    fetch('api/latest.php').then(res => res.json())
  ])
  .then(([user, latest]) => {
    if (userbox) {
      if (user.name) {
        userbox.innerHTML = `
          Bejelentkezve: <strong>${user.name}</strong> 
          <button onclick="logout()" style="margin-left:10px;">Kijelentkezés</button>
        `;
      } else {
        userbox.innerHTML = `<a href="login.html">[Bejelentkezés]</a>`;
      }
    }

    if (mainNav) {
      let menuHTML = `<a href="index.php">Kezdőlap</a>`;
      
      if (user.uid !== undefined && user.uid !== null) {
        const qid = latest.qid;
        const qParam = qid ? `?qid=${qid}` : "";

        menuHTML += ` | <a href="poll.html${qParam}">Szavazok</a>`;
        menuHTML += ` | <a href="result.html${qParam}">Eredmények</a>`;

        if (user.uid == 0) {
          menuHTML += ` | <a href="admin.html">Új kérdés</a>`;
          menuHTML += ` | <a href="dashboard.html">Kérdéskezelés</a>`;
        }
      }
      mainNav.innerHTML = menuHTML;
    }
  })
  .catch(() => {
    if (mainNav) mainNav.innerHTML = `<a href="index.php">Kezdőlap</a>`;
  });
});

function logout() {
  if (!confirm('Biztosan kijelentkezel?')) return;
  fetch('api/logout.php', { method: 'POST', credentials: 'include' })
    .then(() => { location.href = 'index.php'; });
}
